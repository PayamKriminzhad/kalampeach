from django.contrib import admin

from .models import Dashbord, Token

admin.site.register(Dashbord)
admin.site.register(Token)