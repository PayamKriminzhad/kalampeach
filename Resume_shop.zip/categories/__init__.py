default_app_config = 'categories.apps.CategoriesConfig'
