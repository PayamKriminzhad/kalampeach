from django.apps import AppConfig


class DynamicsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    verbose_name = 'ماژول متغیر ها'
    name = 'dynamics'